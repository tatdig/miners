m = Map("cgminer", translate(""), "<a href='https://www.tdcoincore.org/bcexplorer/' target='_blank'>TDCoin blockchain explorer</a>")

conf = m:section(TypedSection, "cgminer", "miner")
conf.anonymous = true
conf.addremove = false

pooluser = conf:option(Value, "pooluser", translate("TDCoin wallet addres") ,translate("Please set to your own TDCoin wallet address."))


stats = m:section(Table, luci.controller.cgminer.summary(), "Miner Status")
stats:option(DummyValue, "elapsed", translate("Elapsed"))
stats:option(DummyValue, "ghs5s", translate("GH/S(5s)"))
stats:option(DummyValue, "ghsav", translate("GH/S(avg)"))

local data = {}
local flag
flag,data = luci.controller.cgminer.blocks()

if(flag == 0 or data == {}) then
	bls = m:section(Table, data, "Found Blocks")
	bls:option(DummyValue, "Comment", "")
	
else
	bls = m:section(Table, data, "FoundBlocks")
	bls:option(DummyValue, "blockInfo", translate("Block Info"))
end

local apply = luci.http.formvalue("cbi.apply")
if apply then
    io.popen("/etc/init.d/cgminer restart")
end
    
return m
