./t-rex -a x16r -o stratum+tcp://rvn.coinfoundry.org:3172 -u YOUR_WALLET_ADDRESS
