t-rex -a bcd -o stratum+tcp://bcd.coinfoundry.org:3056 -u YOUR_WALLET_ADDRESS
